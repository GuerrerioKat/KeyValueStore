#ifndef SERVER_H
#define SERVER_H

#include <map>
#include <string>
#include <mutex>
#include <pthread.h>
#include <memory>
#include "table.h"
#include "client_connection.h"

class Server {
private:
  // TODO: add member variables
  int listen_fd;
  std::map<std::string, std::unique_ptr<Table>> tables;
  std::mutex tables_mutex;
  std::mutex log_mutex;

  // copy constructor and assignment operator are prohibited
  Server( const Server & );
  Server &operator=( const Server & );

public:
  Server();
  ~Server();

  void listen( const std::string &port );
  void server_loop();

  static void *client_worker( void *arg );

  void log_error( const std::string &what );
  void create_table( const std::string &name );
  Table *find_table( const std::string &name );
  void print_tables();
};


#endif // SERVER_H
